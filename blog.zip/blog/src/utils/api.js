import axios from 'axios'

const API_BASE = 'https://jsonplaceholder.typicode.com';

// Create an Axios instance
const axiosInstance = axios.create({
  baseURL: API_BASE, // Set your base URL
});

// Add a request interceptor (optional: for logging or headers)
axiosInstance.interceptors.request.use(
  (config) => {
    console.log('AXIOS REQUEST:', config);
    return config;
  },
  (error) => Promise.reject(error)
);

export default axiosInstance;
