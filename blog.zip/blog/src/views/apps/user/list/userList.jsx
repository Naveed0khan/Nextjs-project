'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'

// MUI Components
import { Card, CardHeader, Table, TableHead, TableBody, TableRow, TableCell, TableContainer, Paper, Button, Chip, Typography , IconButton, Tooltip } from '@mui/material'
import { styled } from '@mui/system'
import VisibilityIcon from '@mui/icons-material/Visibility'
// Styled components for improved design
const StyledCard = styled(Card)(({ theme }) => ({
  margin: theme.spacing(2),
  boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
  borderRadius: '10px',
}))

const StyledTable = styled(Table)(({ theme }) => ({
  minWidth: 650,

  '& th, td': {
    padding: theme.spacing(2),
    textAlign: 'left',
  },
}))

const UserListTable = ({ tableData }) => {
  const [data, setData] = useState(tableData || [])
  const { lang: locale } = useParams()

  useEffect(() => {
    console.log('Data:', data)
  }, [data])

  return (
    <StyledCard>
      <CardHeader
        title={<Typography variant="h6" color="primary">User List</Typography>}
        subheader="Detailed list of users with associated companies."
        sx={{ backgroundColor: '#f5f5f5', borderRadius: '10px 10px 0 0' }}
      />
      <TableContainer component={Paper} sx={{ borderRadius: '0 0 10px 10px' }}>
        <StyledTable>
          <TableHead>
            <TableRow>
              <TableCell><Typography variant="subtitle2">ID</Typography></TableCell>
              <TableCell><Typography variant="subtitle2">Full Name</Typography></TableCell>
              <TableCell><Typography variant="subtitle2">Email</Typography></TableCell>
              <TableCell><Typography variant="subtitle2">Address</Typography></TableCell>
              <TableCell><Typography variant="subtitle2">Company</Typography></TableCell>
              <TableCell><Typography variant="subtitle2">Actions</Typography></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.length > 0 ? (
              data.map((user, index) => (
                <TableRow key={index}>
                  <TableCell>{user.id}</TableCell>
                  <TableCell>{user.name || 'N/A'}</TableCell>
                  <TableCell>{user.email || 'N/A'}</TableCell>
                  <TableCell>{`${user.address.street}, ${user.address.city} (${user.address.zipcode})`}</TableCell>
                  <TableCell>
  <Chip 
    label={user.company.name} 
    color={user.company.name === "SpecificCompany" ? "success" : "success"} 
  />
</TableCell>

                  <TableCell>
                  <Tooltip title="View Post" placement="top">
                      <IconButton
                        component={Link}
                        href={`/user/posts/${user.id}`}
                        variant="contained"
                        size="small"
                        sx={{
                          color: '#1976d2',
                          '&:hover': {
                            backgroundColor: '#1976d2',
                            color: 'white',
                          },
                        }}
                      >
                        <VisibilityIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} align="center">
                  No data available
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </StyledTable>
      </TableContainer>
    </StyledCard>
  )
}

export default UserListTable
