'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'

// MUI Components
import { Card, CardHeader, Table, TableHead, TableBody, TableRow, TableCell, TableContainer, Paper, Button, IconButton, Tooltip } from '@mui/material'
import VisibilityIcon from '@mui/icons-material/Visibility'

const UserListTable = ({ tableData }) => {
  console.log('Received tableData:', tableData); // Debugging

  const [data, setData] = useState([]); // Initialize as empty array

  // Update state when tableData changes
  useEffect(() => {
    if (tableData) {
      // Ensure tableData is an array
      setData(Array.isArray(tableData) ? tableData : [tableData]); // Wrap in array if it's not already
    }
  }, [tableData]); // Trigger effect when tableData changes

  return (
    <Card sx={{ boxShadow: 3, borderRadius: 2, marginTop: 2 }}>
      <CardHeader title="" sx={{ backgroundColor:  '#f5f5f5', color: '#000', fontWeight: 'bold' }} />
      <TableContainer component={Paper} sx={{ borderRadius: 2, overflow: 'hidden' }}>
        <Table>
          <TableHead sx={{ backgroundColor: '#f5f5f5', color: 'white' }}>
            <TableRow>
              <TableCell sx={{ fontWeight: 'bold' }}>User</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>ID</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>Title</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>Body</TableCell>
            
            </TableRow>
          </TableHead>
          <TableBody>
            {data.length > 0 ? (
              data.map((item, index) => (
                <TableRow
                  key={index}
                  sx={{
                    '&:hover': {
                      backgroundColor: '#f1f1f1', // Hover effect
                    },
                  }}
                >
                  <TableCell>{item.userId}</TableCell>
                  <TableCell>{item.id}</TableCell>
                  <TableCell>{item.title}</TableCell>
                  <TableCell>{item.body}</TableCell>
                  <TableCell>
                    <Tooltip title="View Post" placement="top">
                      <IconButton
                        component={Link}
                        href={`/post/view/${item.id}`}
                        variant="contained"
                        size="small"
                        sx={{
                          color: '#1976d2',
                          '&:hover': {
                            backgroundColor: '#1976d2',
                            color: 'white',
                          },
                        }}
                      >
                        <VisibilityIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} align="center" sx={{ color: 'gray', fontStyle: 'italic' }}>
                  No data available
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Card>
  )
}

export default UserListTable
