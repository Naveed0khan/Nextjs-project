'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'

// MUI Components
import { Card, CardHeader, Table, TableHead, TableBody, TableRow, TableCell, TableContainer, Paper, Button } from '@mui/material'

const UserListTable = ({ userData }) => {
  const [data, setData] = useState(userData || [])
  const { lang: locale } = useParams()

  useEffect(() => {
    console.log('Data:', data)
  }, [data])

  return (
    <Card>
      <CardHeader title="User List" />
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>User ID</TableCell>
              <TableCell>ID</TableCell>
              <TableCell>Title</TableCell>
              <TableCell>Body</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.length > 0 ? (
              data.map((item, index) => (
                <TableRow key={index}>
                  <TableCell>{item.userId}</TableCell>
                  <TableCell>{item.id}</TableCell>
                  <TableCell>{item.title}</TableCell>
                  <TableCell>{item.body}</TableCell>
                  <TableCell>
                    <Button component={Link} href={`/user/posts/${item.id}`} variant="contained" size="small">
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} align="center">
                  No data available
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Card>
  )
}

export default UserListTable
