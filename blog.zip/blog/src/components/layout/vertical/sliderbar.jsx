'use client'

import { useState } from 'react'
import { Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText, IconButton, AppBar, Toolbar, Typography } from '@mui/material'
import HomeIcon from '@mui/icons-material/Home'
import PeopleIcon from '@mui/icons-material/People'
import SettingsIcon from '@mui/icons-material/Settings'
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft'
import ChevronRightIcon from '@mui/icons-material/ChevronRight'
import MenuIcon from '@mui/icons-material/Menu'
import Link from 'next/link'

const Sidebar = () => {
  const [open, setOpen] = useState(false) // Start with sidebar closed by default

  // Toggle sidebar open/close
  const toggleDrawer = () => {
    setOpen(!open)
  }

  return (
    <>
      {/* Top AppBar with Menu Button to Open Sidebar */}
      <AppBar position="sticky">
        <Toolbar>
          <IconButton edge="start" color="inherit" aria-label="menu" onClick={toggleDrawer}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6">
            Your Application
          </Typography>
        </Toolbar>
      </AppBar>

      {/* Sidebar */}
      <Drawer
        variant="persistent"
        anchor="left"
        open={open}
        sx={{
          width: open ? 240 : 60, // Change width based on `open` state
          flexShrink: 0,
          '& .MuiDrawer-paper': { width: open ? 240 : 60, boxSizing: 'border-box' }
        }}
      >
        {/* Toggle Button (close/open) */}
        <IconButton
          sx={{
            position: 'absolute',
            top: 20,
            left: open ? 240 - 36 : 60 - 36, // Adjust for close button size
            zIndex: 1
          }}
          onClick={toggleDrawer}
        >
          {open ? <ChevronLeftIcon /> : <ChevronRightIcon />}
        </IconButton>

        {/* Sidebar Links */}
        <List>
          <ListItem disablePadding>
            <ListItemButton component={Link} href="/">
              <ListItemIcon>
                <HomeIcon />
              </ListItemIcon>
              {open && <ListItemText primary="Home" />}
            </ListItemButton>
          </ListItem>

          <ListItem disablePadding>
            <ListItemButton component={Link} href="/posts/all">
              <ListItemIcon>
                <PeopleIcon />
              </ListItemIcon>
              {open && <ListItemText primary="All posts" />}
            </ListItemButton>
          </ListItem>

          <ListItem disablePadding>
            <ListItemButton component={Link} href="/settings">
              <ListItemIcon>
                <SettingsIcon />
              </ListItemIcon>
              {open && <ListItemText primary="Settings" />}
            </ListItemButton>
          </ListItem>
        </List>
      </Drawer>
    </>
  )
}

export default Sidebar
