
import React from 'react';
import { Container, Typography } from '@mui/material';
import UserListTable from '../../../../views/apps/user/list'
import api from '@/utils/api'


// Fetch orders using the native fetch API
async function fetchuser() {
  try {
    const response = await api.get('/users');
    if (response.status === 200) {
      return response.data; // Return the results array from the response data
    } else {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
  } catch (error) {
    console.error('Error fetching users:', error);
    throw error;
  }
}

const User = async () => {
  let data = [];
  let error = null;

  try {
    data = await fetchuser();
  } catch (err) {
    error = err.message;
  }
  return (
    <Container>
    
      <Typography variant="h4" gutterBottom>
        
      </Typography>
      {error ? (
        <Typography>Error: {error}</Typography>
      ) : (
        <UserListTable userData={data}/>
       
      )}
       
    </Container>
  );
};

export default User;
