
import React from 'react';
import Postlist from '../../../../../views/apps/user/view/index'
 import api from '@/utils/api'


const Page = async ({ params }) => {
  const { id } = params; // Extract ID from params

  try {
    // Fetch HR data based on department ID
    const postResponse = await api.get(`/posts/${id}`);
    const posts = postResponse.data;
    // Render the page with the fetched data
    return (
      <div>
        <Postlist tableData={posts} />
      </div>
    );
  } catch (error) {
    console.error('Error fetching data:', error);

    // Display an error message to the user if something goes wrong
    return (
      <div>
        <p>Failed to load data. Please try again later.</p>
      </div>
    );
  }
};

export default Page;
