// Next Imports
import Sidebar from "../components/layout/vertical/sliderbar";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        {/* You can add metadata like title, meta tags, etc. here */}
      </head>
      <body>
        <Sidebar />
        <main>{children}</main>
      </body>
    </html>
  );
}
